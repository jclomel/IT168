/*
 * File name: BubbleTeaOrder.java
 *
 * Programmer: Justin Lomelino
 * ULID: jclomel
 *
 * Date: Oct 15, 2016
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Dr. Tonya Pierce
 * Lab Section: 20
 * Lab Instructor: Dr. Tonya Pierce 
 */
package edu.ilstu;

/**
 * represents a single order at Bubble Tea World
 *
 * @author Justin Lomelino
 *
 */
public class BubbleTeaOrder
{
	private final double SALES_TAX = 0.075;
	private final double REGULAR_PRICE = 3.75;
	private final double LARGE_PRICE = 4.50;
	private final double PRICE_PER_TEXTURE = 0.50;
	private int numBoba;
	private int numMangoJelly;
	private int numPopBoba;
	private double discountAmount;
	private String size;
	private String flavor;
	
	
	public int getNumBoba(){
		return numBoba;
	}
	public int getNumMangoJelly(){
		return numMangoJelly;
	}
	public int getNumPopBoba(){
		return numPopBoba;
	}
	public double getDiscountAmount(){
		return discountAmount;
	}
	public String getSize(){
		return size;
	}
	public String getFlavor(){
		return flavor;
	}
	
	public void setNumBoba(int numServings){
		numBoba = numServings;
	}
	public void setNumMangoJelly(int numServings){
		numMangoJelly = numServings;
	}
	public void setNumPopBoba(int numServings){
		numPopBoba = numServings;
	}
	public void setSize(String size){
		this.size = size;
	}
	public void setFlavor(String flavor){
		this.flavor = flavor;
	}
	public double getRegularPrice(){
		return REGULAR_PRICE;
	}
	public double getLargePrice(){
		return LARGE_PRICE;
	}
	
	public void applyDiscount(Rewards rewardAccount){
		discountAmount = rewardAccount.returnDiscountAmount();
		if(rewardAccount.getNumPoints() <= 99){
			// do nothing in this case, reward points don't change
			return;
		}
		else if(rewardAccount.getNumPoints() <= 199){
			rewardAccount.deductPoints(100);
		}
		else{
			rewardAccount.deductPoints(200);
		}
	}
	public double calculateSubTotal(){
		double subTotal;
		double drinkCost = 0;
		double textureCost = 0;
		
		if(size.equals("12")){
			drinkCost = REGULAR_PRICE;
		}
		else if(size.equals("16")){
			drinkCost = LARGE_PRICE;
		}
		else{
			//something went wrong, a drink order should always be either
			//"12" or "16"
			System.out.println("A drink order must have a size value of \"12\" or \"16\"!");
			System.exit(1);
		}
		
		textureCost += numBoba * PRICE_PER_TEXTURE;
		textureCost += numMangoJelly * PRICE_PER_TEXTURE;
		textureCost += numPopBoba * PRICE_PER_TEXTURE;
		
		subTotal = drinkCost + textureCost - discountAmount;
		return subTotal;
	}
	public double calculateTaxAmount(){
		return calculateSubTotal() * SALES_TAX;
	}
	public double calculateTotalCost(){
		return calculateSubTotal() + calculateTaxAmount();
	}
}
