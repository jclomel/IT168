/*
 * File name: Rewards.java
 *
 * Programmer: Justin Lomelino
 * ULID: jclomel
 *
 * Date: Oct 15, 2016
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Dr. Tonya Pierce
 * Lab Section: 20
 * Lab Instructor: Dr. Tonya Pierce 
 */
package edu.ilstu;

/**
 * represents one customer rewards account at Bubble Tea World
 *
 * @author Justin Lomelino
 *
 */
public class Rewards
{
	private String fullName;
	private String accountID;
	private int numPoints;
	
	Rewards(){
		this("anon", "none", 0);
	}
	Rewards(String fullName, String accountID, int numPoints){
		this.fullName = fullName;
		this.accountID = accountID;
		this.numPoints = numPoints;
	}
	
	public String getFullName(){
		return fullName;
	}
	public String getAccountID(){
		return accountID;
	}
	public int getNumPoints(){
		return numPoints;
	}
	
	public void addPoints(double subTotal){
		numPoints += ((int)subTotal)*2;
	}
	public int getPointsAdded(double subTotal){
		return ((int)subTotal * 2);
	}
	public void deductPoints(int points){
		numPoints -= points;
	}
	public double returnDiscountAmount(){
		if(numPoints <= 99){
			return 0;
		}
		else if(numPoints <= 199){
			return 1.00;
		}
		else{
			return 2.50;
		}
	}
}
