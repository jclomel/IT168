/*
 * File name: BubbleTeaOrderApp.java
 *
 * Programmer: Justin Lomelino
 * ULID: jclomel
 *
 * Date: Oct 15, 2016
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Dr. Tonya Pierce
 * Lab Section: 20
 * Lab Instructor: Dr. Tonya Pierce 
 */
package edu.ilstu;

import java.util.Scanner;

/**
 * This class is the main driver of Bubble Tea Order App.
 * 	note: I met the requirements for output as described in the assignment,
 * 		but I have made a few improvements to supply the user with data that
 * 		we had already calculated but that wasn't displayed under the order summary.
 * 		I have also added in code to handle when a user doesn't have enough reward
 * 		points in their account to apply a discount, and also when a user says they
 * 		do not have an account that they want to use(we are pretending we made them an
 * 		account elsewhere in this instance).
 *
 * @author Justin Lomelino
 *
 */
public class BubbleTeaOrderApp
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		// Rather than creating a new Scanner object each time we need input in a function,
		// let's just create one here and reuse it as necessary
		Scanner kb = new Scanner(System.in);
		
		// A dummy reward account to be used for testing.  Later, this would be modified to be an array
		// holding all rewards account objects, so that the phone number entered can be checked against
		// all registered reward accounts.
		Rewards rewards = new Rewards("Abraham Lincoln", "5551337", 0);
		
		// A new order should be created for each transaction.
		BubbleTeaOrder order = new BubbleTeaOrder();
		
		// The main algorithm has been moved into private functions within this class
		// to make following the logic of the algorithm easier.
		displayMenu(order);
		designDrink(kb, order);
		dealWithRewards(kb, order, rewards);
		displayOrderSummary(order, rewards);
		
		kb.close();

	}
	
	private static void displayMenu(BubbleTeaOrder order){
		System.out.println("\tBubble Tea World Menu\n");
		System.out.println("\t\tRegular\tLarge");
		System.out.printf("Bubble Tea\t%.2f\t%.2f\n\n", order.getRegularPrice(), order.getLargePrice());
		System.out.println("Bubble Flavors");
		System.out.println("\tAlmond");
		System.out.println("\tTaro");
		System.out.println("\tChai\n");
		System.out.println("Textures ($0.50 each)");
		System.out.println("\tBoba");
		System.out.println("\tPop Boba");
		System.out.println("\tMango Jelly\n");	
	}
	private static void designDrink(Scanner kb, BubbleTeaOrder order){
		boolean flavorSet = false;
		System.out.println("Welcome to bubble tea world! Please design your drink.");
		do{
			System.out.print("Enter the flavor: ");
			order.setFlavor(kb.nextLine().toLowerCase());
			if ((order.getFlavor().equals("almond"))||(order.getFlavor().equals("taro"))||(order.getFlavor().equals("chai"))){
				flavorSet = true;
			}
			else{
				System.out.println("Please enter either \"Almond\", \"Taro\", or \"Chai\".");
			}
		}while(!flavorSet);
		
		boolean sizeSet = false;
		do{
			System.out.print("Enter the drink size (12 or 16): ");
			order.setSize(kb.nextLine());
			if((order.getSize().equals("12"))||(order.getSize().equals("16"))){
				sizeSet = true;
			}
			else{
				System.out.println("Please enter either \"12\" or \"16\".");
			}
		}while(!sizeSet);
		
		boolean likeTexturesSet = false;
		boolean wouldLikeTextures = false;
		do{
			System.out.print("Would you like add textures (Y or N)?: ");
			String addTextures = kb.nextLine().toLowerCase();
			if ((addTextures.equals("y"))||(addTextures.equals("n"))){
				likeTexturesSet = true;
				if(addTextures.equals("y")){
					wouldLikeTextures = true;
				}
			}
			else{
				System.out.println("Please enter either \"Y\" or \"N\".");
			}
		}while(!likeTexturesSet);
		
		if(wouldLikeTextures){
			boolean bobaSet = false;
			do{
				System.out.print("Enter the number of boba servings (0, 1 or 2): ");
				order.setNumBoba(kb.nextInt());
				if((order.getNumBoba() == 1)||(order.getNumBoba() == 2)||(order.getNumBoba() == 0)){
					bobaSet = true;
				}
				else{
					System.out.println("Please enter either \"0\", \"1\" or \"2\".");
				}
			}while(!bobaSet);
			
			boolean popBobaSet = false;
			do{
				System.out.print("Enter the number of pop boba servings (0, 1 or 2): ");
				order.setNumPopBoba(kb.nextInt());
				if((order.getNumPopBoba() == 1)||(order.getNumPopBoba() == 2)||(order.getNumPopBoba() == 0)){
					popBobaSet = true;
				}
				else{
					System.out.println("Please enter either \"0\", \"1\" or \"2\".");
				}
			}while(!popBobaSet);
			
			boolean mangoSet = false;
			do{
				System.out.print("Enter the number of boba servings (0, 1 or 2): ");
				order.setNumMangoJelly(kb.nextInt());
				if((order.getNumMangoJelly() == 1)||(order.getNumMangoJelly() == 2)||(order.getNumMangoJelly() == 0)){
					mangoSet = true;
				}
				else{
					System.out.println("Please enter either \"0\", \"1\" or \"2\".");
				}
			}while(!mangoSet);
			kb.nextLine();		//clearing the cursor to remove the newline character
		}
	}
	private static void dealWithRewards(Scanner kb, BubbleTeaOrder order, Rewards rewards){
		boolean rewardsSet = false;
		do{
			System.out.print("Do you have a rewards account you would like to use(Y or N)?: ");
			String hasRewards = kb.nextLine().toLowerCase();
			if((hasRewards.equals("y"))||(hasRewards.equals("n"))){
				rewardsSet = true;
				if(hasRewards.equals("y")){
					processRewardsAccount(kb, order, rewards);
				}
				else{
					System.out.println("\tIf you do not already have a rewards account, a rewards account has been created for you.");
					System.out.println("\tIf you do already have a rewards account, the points earned from this order will still be credited to your existing account.");
				}
				rewards.addPoints(order.calculateSubTotal());
			}
			else{
				System.out.println("Please enter either \"Y\" or \"N\".");
			}
		}while(!rewardsSet);
	}
	private static void processRewardsAccount(Scanner kb, BubbleTeaOrder order, Rewards rewards){
		boolean phoneNumberSet = false;
		do{
			System.out.print("What is your phone number(digits only)?: ");
			String phoneNumber = kb.nextLine();
			if(phoneNumber.equals(rewards.getAccountID())){
				phoneNumberSet = true;
				System.out.println("You have " + rewards.getNumPoints() + " points.");
				boolean usePointsSet = false;
				do{
					System.out.print("Would you like to use your reward points (Y or N)?: ");
					String usePoints = kb.nextLine().toLowerCase();
					if((usePoints.equals("y"))||(usePoints.equals("n"))){
						usePointsSet = true;
						if(usePoints.equals("y")){
							if(rewards.getNumPoints() < 100){
								System.out.println("You don't have enough points!");
							}
							else{
								order.applyDiscount(rewards);
							}
						}
					}
					else{
						System.out.println("Please enter either \"Y\" or \"N\".");
					}
				}while(!usePointsSet);
			}
			else{
				System.out.println("Phone number is not valid!");
			}
		}while(!phoneNumberSet);
	}
	private static void displayOrderSummary(BubbleTeaOrder order, Rewards rewards){
		System.out.println("\n\t\tOrder Summary\n");
		System.out.println("Hello, " + rewards.getFullName() + "!\n");
		if(order.getDiscountAmount() != 0){
			if(order.getDiscountAmount() == 1.00){
				System.out.println("You used 100 reward points.");
			}
			else if(order.getDiscountAmount() == 2.50){
				System.out.println("You used 200 reward points.");
			}
		}
		if(rewards.getNumPoints() != 0){
			System.out.println("You gained " + rewards.getPointsAdded(order.calculateSubTotal()) + " reward points this order.");
			System.out.println("You have " + rewards.getNumPoints() + " reward points remaining.\n");
		}
		System.out.println("Drink: " + order.getSize() + "oz. " + order.getFlavor().substring(0,1).toUpperCase() + order.getFlavor().substring(1));
		System.out.print("Textures ordered: ");
		if(order.getNumBoba() !=0){
			System.out.print(order.getNumBoba() + " boba  ");
		}
		if(order.getNumPopBoba() != 0){
			System.out.print(order.getNumPopBoba() + " pop boba  ");
		}
		if(order.getNumMangoJelly() != 0){
			System.out.print(order.getNumMangoJelly() + " mango jelly");
		}
		if((order.getNumBoba() == 0)&&(order.getNumMangoJelly() == 0)&&(order.getNumPopBoba() ==0)){
			System.out.print("none");
		}
		System.out.print("\n");
		System.out.printf("\tDrink Cost:\t $%.2f\n\n", ((order.calculateSubTotal() + order.getDiscountAmount())));
		if(order.getDiscountAmount() != 0){
			System.out.printf("Rewards Discount:\t-$%.2f\n\n", order.getDiscountAmount());
		}
		System.out.printf("Sub-Total:\t\t $%.2f\n", order.calculateSubTotal());
		System.out.printf("Sales Tax:\t\t $%.2f\n", order.calculateTaxAmount());
		System.out.printf("Total:\t\t\t $%.2f\n", order.calculateTotalCost());
		
		
	}
	
}
