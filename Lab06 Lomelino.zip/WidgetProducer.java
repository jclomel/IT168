/*
 * File name: WidgetProducer.java
 *
 * Programmer: Justin Lomelino
 * ULID: jclomel
 *
 * Date: Sep 27, 2016
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Dr. Tonya Pierce
 * Lab Section: 20
 * Lab Instructor: Dr. Tonya Pierce 
 */
package edu.ilstu;

/**
 * Calculates widget production
 *
 * @author Justin Lomelino
 *
 */
public class WidgetProducer
{
	private int widgetsPerHour;
	private final int PRODUCTION_HOURS_PER_DAY = 16;
	
	WidgetProducer(){
	}
	WidgetProducer(int wph){
		widgetsPerHour = wph;
	}
	public int getWidgetsPerHour(){
		return widgetsPerHour;
	}
	public double getNumberOfDays(int numWidgets){
		//numWidgets is cast to a double so the result returned is a double
		return (double)numWidgets/(widgetsPerHour*PRODUCTION_HOURS_PER_DAY);
	}
}
