/*
 * File name: WidgetTester.java
 *
 * Programmer: Justin Lomelino
 * ULID: jclomel
 *
 * Date: Sep 27, 2016
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Dr. Tonya Pierce
 * Lab Section: 20
 * Lab Instructor: Dr. Tonya Pierce 
 */
package edu.ilstu;

/**
 * Demonstrates the WidgetProducer class by instantiating WidgetProducers with
 * various values
 *
 * @author Justin Lomelino
 *
 */
public class WidgetTester
{

	public static void main(String[] args)
	{
		WidgetProducer wpa = new WidgetProducer(8);
		double numDays = wpa.getNumberOfDays(1000);
		System.out.printf("1,000 widgets produced at " + wpa.getWidgetsPerHour() + " per hour will take %.1f days.\n", numDays);

		WidgetProducer wpb = new WidgetProducer(1000);
		numDays = wpb.getNumberOfDays(100000);
		System.out.printf("100,000 widgets produced at " + wpb.getWidgetsPerHour() + " per hour will take %.1f days.\n", numDays);

		WidgetProducer wpc = new WidgetProducer(100);
		numDays = wpc.getNumberOfDays(200);
		System.out.printf("200 widgets produced at " + wpc.getWidgetsPerHour() + " per hour will take %.1f days.\n", numDays);

	}

}
