/*
 * File name: Truck.java
 *
 * Programmer: Justin Lomelino
 * ULID: jclomel
 *
 * Date: Sep 27, 2016
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Dr. Tonya Pierce
 * Lab Section: 20
 * Lab Instructor: Dr. Tonya Pierce 
 */
package edu.ilstu;

/**
 * Represents a truck
 *
 * @author Justin Lomelino
 *
 */
public class Truck
{
	private int cylinders;
	private String manufacturer;
	private double load;
	private double tow;
	
	Truck(){
		
	}
	Truck(int cylinders){
		this.cylinders = cylinders;
	}
	Truck(int cylinders, String manufacturer){
		this(cylinders);
		this.manufacturer = manufacturer;
	}
	Truck(int cylinders, String manufacturer, double load){
		this(cylinders, manufacturer);
		this.load = load;
	}
	Truck(int cylinders, String manufacturer, double load, double tow){
		this(cylinders, manufacturer, load);
		this.tow = tow;
	}
	
	public int getCylinders(){
		return cylinders;
	}
	public void setCylinders(int cylinders){
		this.cylinders = cylinders;
	}
	public String getManufacturer(){
		return manufacturer;
	}
	public void setManufacturer(String manufacturer){
		this.manufacturer = manufacturer;
	}
	public double getLoad(){
		return load;
	}
	public void setLoad(double load){
		this.load = load;
	}
	public double getTow(){
		return tow;
	}
	public void setTow(double tow){
		this.tow = tow;
	}
	public String toString(){
		return "\n\ncylinders = " + cylinders
				+ "\nmanufacturer = " + manufacturer
				+ "\nload = " + load
				+ "\ntow = " + tow;
	}
}
