/*
 * File name: Triangle.java
 *
 * Programmer: Justin Lomelino
 * ULID: jclomel
 *
 * Date: Oct 18, 2016
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Dr. Tonya Pierce
 * Lab Section: 20
 * Lab Instructor: Dr. Tonya Pierce 
 */
package edu.ilstu;

import java.util.Scanner;

/**
 * draws a triangle made of asterisks to the screen based on the integer given by the user
 *
 * @author Justin Lomelino
 *
 */
public class Triangle
{
	public static void main(String[] args)
	{
		Scanner kb = new Scanner(System.in);
		boolean done = false;
		int input = 0;
		while(!done){
			System.out.print("Enter the size of the triangle as an integer between 1 and 50: ");
			input = kb.nextInt();
			if(input > 50){
				System.out.println("The integer must be less than or equal to 50!");
			}
			else if(input < 1){
				System.out.println("The integer must be greater than 0!");
			}
			else done = true;
		}
		//draw half the triangle
		for(int i=1; i<=input; i++){
			for(int p=1; p<=i; p++){
				System.out.print("*");
			}
			System.out.print("\n");
		}
		//draw the other half
		for(int i=input-1; i>0; i--){
			for(int p=1; p<=i; p++){
				System.out.print("*");
			}
			System.out.print("\n");
		}
		kb.close();

	}

}
