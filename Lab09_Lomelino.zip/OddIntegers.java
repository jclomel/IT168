/*
 * File name: OddIntegers.java
 *
 * Programmer: Justin Lomelino
 * ULID: jclomel
 *
 * Date: Oct 18, 2016
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Dr. Tonya Pierce
 * Lab Section: 20
 * Lab Instructor: Dr. Tonya Pierce 
 */
package edu.ilstu;

import java.util.Scanner;

/**
 * determines and displays the sum of the first n integers, with n supplied by the users
 *
 * @author Justin Lomelino
 *
 */
public class OddIntegers
{
	public static void main(String[] args)
	{
		Scanner kb = new Scanner(System.in);
		System.out.print("Enter an integer for n: ");
		int n = kb.nextInt();
		int sum = 0;
		int position = 1;
		for(int i = 1; i<=n; i++){
			sum += position;
			position += 2;
		}
		System.out.println("The sum of the first " + n +" odd integers is " + sum);
		kb.close();
	}

}
