/*
 * File name: CircleDriver.java
 *
 * Programmer: Justin Lomelino
 * ULID: jclomel
 *
 * Date: Sep 20, 2016
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Dr. Tonya Pierce
 * Lab Section: 20
 * Lab Instructor: Dr. Tonya Pierce 
 */
package edu.ilstu;

import java.util.Scanner;


/**
 * Demonstrates the Circle class
 *
 * @author Justin Lomelino
 *
 */
public class CircleDriver
{


	
	
	public static void main(String[] args)
	{
		Scanner keys = new Scanner(System.in);
		double radius;
		double area;
		double diameter;
		double circumference;
		
		System.out.println("Please enter the radius of the circle: ");
		radius = keys.nextInt();
		
		Circle circle = new Circle(radius);
		area = circle.calculateArea();
		diameter = circle.calculateDiameter();
		circumference = circle.calculateCircumference();
		
		System.out.print("Area: " + area +"\nDiameter: " + diameter + "\nCircumference: " + circumference);
		keys.close();
		
		

	}

}
