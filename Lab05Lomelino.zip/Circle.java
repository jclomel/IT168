/*
 * File name: Circle.java
 *
 * Programmer: Justin Lomelino
 * ULID: jclomel
 *
 * Date: Sep 20, 2016
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Dr. Tonya Pierce
 * Lab Section: 20
 * Lab Instructor: Dr. Tonya Pierce 
 */
package edu.ilstu;

/**
 * Represents a circle, and includes useful circle-related methods
 *
 * @author Justin Lomelino
 *
 */
public class Circle
{
	private double radius;
	public static final double PI = 3.14159;
	
	public Circle(){
		this(0);
	}
	public Circle(double radius2){
		this.radius = radius2;
	}
	
	public void setRadius(double radius){
		this.radius = radius;
	}
	public double getRadius(){
		return this.radius;
	}
	
	
	public double calculateArea(){
		return PI * radius * radius;
	}
	public double calculateDiameter(){
		return radius * 2;
	}
	public double calculateCircumference(){
		return 2 * PI * radius;
	}
	
}
