/*
 * File name: Book.java
 *
 * Programmer: Justin Lomelino
 * ULID: jclomel
 *
 * Date: Sep 20, 2016
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Dr. Tonya Pierce
 * Lab Section: 20
 * Lab Instructor: Dr. Tonya Pierce 
 */
package edu.ilstu;

/**
 * Handles book sales.  Calculates total, including tax.
 *
 * @author Justin Lomelino
 *
 */
public class Book
{
	public static final double SALES_TAX = 0.075;
	private String title;
	private double price;
	
	public Book(){
		this("NoTitle", 0.0);
	}
	public Book(String title, double price){
		this.title = title;
		this.price = price;
	}
	
	public String getTitle(){
		return title;
	}
	public double getPrice(){
		return price;
	}
	
	public void setTitle(String title){
		this.title = title;
	}
	public void setPrice(double price){
		this.price = price;
	}
	
	public void increasePrice(double percentInc){
		this.price += price * percentInc;
	}
	public double calculateSales(int numBooks){
		double salesTotal;
		salesTotal = (price * numBooks);	//pre-tax
		salesTotal += salesTotal * SALES_TAX;
		return salesTotal;
	}
	public void displaySales(double sales){
		System.out.print("Cost for \"" + title);
		System.out.printf("\": $%.2f\n", sales);
	}
}
