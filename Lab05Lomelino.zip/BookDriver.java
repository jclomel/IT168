/*
 * File name: BookDriver.java
 *
 * Programmer: Justin Lomelino
 * ULID: jclomel
 *
 * Date: Sep 20, 2016
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Dr. Tonya Pierce
 * Lab Section: 20
 * Lab Instructor: Dr. Tonya Pierce 
 */
package edu.ilstu;

import java.util.Scanner;

/**
 * demonstrates the book class, by asking user for number of books sold and then
 * displaying the sales total
 *
 * @author Justin Lomelino
 *
 */
public class BookDriver
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		Scanner keys = new Scanner(System.in);
		
		Book pi = new Book("Life of Pi", 13.50);
		Book harry = new Book("Harry Potter: Goblet of Fire", 22.00);
		
		System.out.println("Please enter the number to buy of \"Life of Pi\": ");
		int numPi = keys.nextInt();
		double piTotal = pi.calculateSales(numPi);
		//System.out.printf("Cost for \"Life of Pi\":  %.2f\n", piTotal);
		pi.displaySales(piTotal);
		
		System.out.println("Please enter the number to buy of \"Harry Potter\": ");
		int numPotter = keys.nextInt();
		double potterTotal = harry.calculateSales(numPotter);
		//System.out.printf("Cost for \"Harry Potter\":  %.2f\n", potterTotal);
		harry.displaySales(potterTotal);
		
		System.out.println("Enter percent increase for \"Life of Pi\": ");
		double piInc = keys.nextDouble();
		System.out.println("Enter percent increase for \"Harry Potter\": ");
		double potterInc = keys.nextDouble();
		pi.increasePrice(piInc);
		harry.increasePrice(potterInc);
		piTotal = pi.calculateSales(numPi);
		potterTotal = harry.calculateSales(numPotter);
		pi.displaySales(piTotal);
		harry.displaySales(potterTotal);
		
		keys.close();
		

	}

}
