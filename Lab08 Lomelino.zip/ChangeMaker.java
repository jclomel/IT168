/*
 * File name: ChangeMaker.java
 *
 * Programmer: Justin Lomelino
 * ULID: jclomel
 *
 * Date: Oct 11, 2016
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Dr. Tonya Pierce
 * Lab Section: 20
 * Lab Instructor: Dr. Tonya Pierce 
 */
package edu.ilstu;

import java.util.Scanner;

/**
 * determines the change to make from a dollar
 *
 * @author Justin Lomelino
 *
 */
public class ChangeMaker
{

	public static void main(String[] args)
	{
		Scanner keys = new Scanner(System.in);
		System.out.println("Item price must be 25 cents to a dollar, in 5-cent increments.\nEnter item price:");
		int price = keys.nextInt();
		
		if (price >= 100){
			System.out.println("Cost is invalid - must be less than 100 cents.");
			System.exit(1);
		}
		else if (price < 25){
			System.out.println("Cost is invalid - must be more than 25 cents.");
			System.exit(1);
		}
		else if (price % 5 != 0){
			System.out.println("Cost is invalid - must be evenly divisible by 5.");
			System.exit(1);
		}
		
		price = 100 - price;
		
		int numQuarters = (int)(price / 25);
		int remainder = price % 25;
		printResult("quarter", numQuarters);
		
		int numDimes = (int)(remainder / 10);
		remainder = remainder % 10;
		printResult("dime", numDimes);
		
		int numNickels = (int)(remainder / 5);
		remainder = remainder %5;
		printResult("nickel", numNickels);
		
		keys.close();
	}
	private static void printResult(String label, int num){
		if (num != 0){
			System.out.printf("%d " + label, num);
			if (num > 1){
				System.out.print("s \n");
			}
			else{
				System.out.print("\n");
			}
		}
	}

}
