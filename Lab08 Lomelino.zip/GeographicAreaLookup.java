/*
 * File name: GeographicAreaLookup.java
 *
 * Programmer: Justin Lomelino
 * ULID: jclomel
 *
 * Date: Oct 11, 2016
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Dr. Tonya Pierce
 * Lab Section: 20
 * Lab Instructor: Dr. Tonya Pierce 
 */
package edu.ilstu;

public class GeographicAreaLookup
{
	public String determineAreaByZip(int zip){
		zip = (int)(zip / 10000);
		switch(zip){
		case 0:
		case 1:
		case 2:
		case 3:
			return "East Coast";
		case 4:
		case 5:
		case 6:
			return "Central Plains";
		case 7:
			return "South";
		case 8:
		case 9:
			return "West";
		default:
			return "invalid zip";
		}
	}
}
