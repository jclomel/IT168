/*
 * File name: GeographicAreaTester.java
 *
 * Programmer: Justin Lomelino
 * ULID: jclomel
 *
 * Date: Oct 11, 2016
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Dr. Tonya Pierce
 * Lab Section: 20
 * Lab Instructor: Dr. Tonya Pierce 
 */
package edu.ilstu;

import java.util.Scanner;

/**
 * tests the GeographicAreaLookup class
 *
 * @author Justin Lomelino
 *
 */
public class GeographicAreaTester
{

	public static void main(String[] args)
	{
		Scanner kb = new Scanner(System.in);
		System.out.println("Please enter a 5 digit zip code:");
		int zip = kb.nextInt();
		GeographicAreaLookup lookup = new GeographicAreaLookup();
		String area = lookup.determineAreaByZip(zip);
		System.out.println(zip + " is in the " + area + " area.");
		kb.close();
	}

}
