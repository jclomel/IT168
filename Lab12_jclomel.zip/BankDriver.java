/*
 * File name: BankDriver.java
 *
 * Programmer: Justin Lomelino
 * ULID: jclomel
 *
 * Date: Nov 14, 2016
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Dr. Tonya Pierce
 * Lab Section: 20
 * Lab Instructor: Dr. Tonya Pierce 
 */
package edu.ilstu;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.util.Scanner;

/**
 * <insert class description here>
 *
 * @author Justin Lomelino
 *
 */
public class BankDriver
{
	private static final String INPUT_FILE = "Transactions.txt";
	private static final String OUTPUT_FILE = "AccountRecord.txt";
	//If this is true, display transaction debug info in the console
	private static final boolean TRANSACTION_DEBUG = false;
	/**
	 * @param args
	 * @throws FileNotFoundException 
	 */
	public static void main(String[] args) throws FileNotFoundException
	{
		//Open the input file
		File f = null;
		try{
			f = new File(INPUT_FILE);
		}
		catch(Exception ex){
			System.out.println(ex.getMessage() +"\n"+ ex.getStackTrace());
			System.exit(1);
		}
		Scanner fr = new Scanner(f);
		//Read the details of the input file
		String accountNumber = fr.nextLine();
		String firstName = fr.nextLine();
		String lastName = fr.nextLine();
		double balance = fr.nextDouble();
		fr.nextLine();//clear the cursor
		//Create a new BankAccount
		BankAccount account = new BankAccount(accountNumber, firstName, lastName, balance);
		System.out.println("Processing account:\n" + account.toString() + "\n");
		//While the file has a transaction remaining, process the transaction, updating the balance and displaying what was done to the console
		while(fr.hasNextLine()){
			String line = fr.nextLine();
			//System.out.println(line);
			String code = line.split(" ")[0];
			String amount = line.split(" ")[1];
			double trans = Double.parseDouble(amount);
			if(code.equals("1")){
				account.processWithdrawal(trans);
				if(TRANSACTION_DEBUG){
					System.out.println("[" + line + "] $" + trans + " WITHDRAWL  BALANCE: " + account.getBalance());
				}
			}
			else if(code.equals("2")){
				account.processDeposit(trans);
				if(TRANSACTION_DEBUG){
					System.out.println("[" + line + "] $" + trans + " DEPOSIT  BALANCE: " + account.getBalance());
				}
			}
			else{
				System.out.println("WARNING: transaction not resolved as deposit or withdrawal[" + line + "]");
			}
		}
		System.out.printf("\nFinal Balance: $%.2f\n", account.getBalance());
		fr.close();
		//Open the output file and write the account details to the file
		File output = null;
		FileWriter out = null;
		try{
			output = new File(OUTPUT_FILE);
			out = new FileWriter(output);
			System.out.println("\nWriting account details to '" + OUTPUT_FILE + "' ...");
			out.write(account.toString());
			System.out.println("Account written to file.");
			out.close();
		}
		catch(Exception ex){
			System.out.println(ex.getMessage() +"\n"+ ex.getStackTrace());
			System.exit(1);
		}
	}

}
