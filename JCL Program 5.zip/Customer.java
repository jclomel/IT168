/*
 * File name: Customer.java
 *
 * Programmer: Justin Lomelino
 * ULID: jclomel
 *
 * Date: Nov 12, 2016
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Dr. Tonya Pierce
 * Lab Section: 20
 * Lab Instructor: Dr. Tonya Pierce 
 */
package edu.ilstu.jclomel;

import java.text.DecimalFormat;

/**
 * <insert class description here>
 *
 * @author Justin Lomelino
 *
 */
public class Customer
{
	private String accountNumber;
	private String firstName;
	private String lastName;
	private Address customerAddress;
	private String phone;
	private Data megabits;
	
	Customer(){
		this("no account number", "no first name", "no last name", null, "no phone number", null);
	}
	Customer(String accountNumber, String firstName, String lastName, Address customerAddress, String phone, Data megabits){
		this.accountNumber = accountNumber;
		this.firstName = firstName;
		this.lastName = lastName;
		this.customerAddress = customerAddress;
		this.phone = phone;
		this.megabits = megabits;
	}
	public String getAccountNumber(){
		return accountNumber;
	}
	public String getFirstName(){
		return firstName;
	}
	public String getLastName(){
		return lastName;
	}
	public Address getCustomerAddress(){
		return customerAddress;
	}
	public String getPhone(){
		return phone;
	}
	public Data getMegabits(){
		return megabits;
	}
	public void setAccountNumber(String accountNumber){
		this.accountNumber = accountNumber;
	}
	public void setFirstName(String firstName){
		this.firstName = firstName;
	}
	public void setLastName(String lastName){
		this.lastName = lastName;
	}
	public void setCustomerAddress(Address address){
		this.customerAddress = address;
	}
	public void setPhone(String phone){
		this.phone = phone;
	}
	public void setMegabits(Data data){
		this.megabits = data;
	}
	/**
	 * structures the class data in a way that is nice for display
	 * @return a String of the class data
	 */
	public String formatLabel(){
		String displayString = 	"Account Number: " + accountNumber + "\n" +
								firstName + " " + lastName + "\n" +
								customerAddress.getStreet() + "\n" +
								customerAddress.getCity() + ", " + customerAddress.getState() + "  " + customerAddress.getZip() + "\n" +
								formatPhone() + "\n";
		return displayString;
	}
	/**
	 * structures the phone number in the desired display format
	 * @return a String of the formatted phone number
	 */
	private String formatPhone(){
		String areaCode = phone.substring(0, 3);
		String firstThree = phone.substring(3, 6);
		String theRest = phone.substring(6);
		return "(" + areaCode + ")" + firstThree + "-" + theRest;
	}
	/**
	 * calculates the bill owed
	 * @return the amount due, as a double
	 */
	public double calculateBill(){
		return megabits.calculateBill();
	}
	
	public String toString(){
		DecimalFormat df = new DecimalFormat("##.00");
		String displayString = formatLabel() +
				"MegaBits Used: " + megabits.getMegabits() + "\n" +
				"Amount Due: $" + df.format(calculateBill()) + "\n";
		return displayString;
	}
}
