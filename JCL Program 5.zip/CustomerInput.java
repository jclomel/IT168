/*
 * File name: CustomerInput.java
 *
 * Programmer: Justin Lomelino
 * ULID: jclomel
 *
 * Date: Nov 12, 2016
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Dr. Tonya Pierce
 * Lab Section: 20
 * Lab Instructor: Dr. Tonya Pierce 
 */
package edu.ilstu.jclomel;

import java.io.File;
import java.util.Scanner;

/**
 * <insert class description here>
 *
 * @author Justin Lomelino
 *
 */
public class CustomerInput
{
	private Scanner in;
	private String outputFile;
	
	@SuppressWarnings("resource")							//this is just to get the compiler to stop complaining about never closing the scanner.
	CustomerInput(File file){
		try{
			in = new Scanner(file).useDelimiter("\\n");
		}
		catch(Exception ex){
			System.out.println(ex.getMessage());
		}
		finally{
			String fileName = file.getName();
			outputFile = (fileName.substring(0,(fileName.length()-3)) + "txt");	//make the name of the output file equal to the name of the
																				//input file, minus the file extension, with '.txt' added to the end
		}
	}
	CustomerInput(){
		System.out.println("CustomerInput should never be instantiated without a file.");
		System.exit(1);
	}
	
	/**
	 * reads in a .csv file, collects the data about each customer, and writes the data to a text file
	 */
	@SuppressWarnings("resource")				//also to keep the compiler from complaining about an unclosed Scanner.  I don't expect
												//this resourceLeak to be a problem since the program executes so quickly and then quits.
												//this could potentially be a problem though if you are using a file with a LOT of entries (millions?)
												//as there will be a new Scanner in existence for each line in the file.
	public void readFile(){
		while(in.hasNext()){
			Scanner line = new Scanner(in.next()).useDelimiter(",");
			Customer customer = new Customer();
			customer.setAccountNumber(line.next());
			customer.setFirstName(line.next());
			customer.setLastName(line.next());
			String street = line.next();
			String city = line.next();
			String state = line.next();
			String zip = line.next();
			Address a = new Address(street, city, state, zip);
			customer.setCustomerAddress(a);
			customer.setPhone(line.next());
			String mb = line.next();
			mb = mb.substring(0, mb.length()-1);
			int newMb = Integer.parseInt(mb);
			Data d = new Data(newMb);
			customer.setMegabits(d);
			CustomerOutput.writeToFile(customer.toString(), outputFile);
			line.close();
		}
	}
	
	public String getOutputFile(){
		return outputFile;
	}
}
