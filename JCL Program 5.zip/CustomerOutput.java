/*
 * File name: CustomerOutput.java
 *
 * Programmer: Justin Lomelino
 * ULID: jclomel
 *
 * Date: Nov 12, 2016
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Dr. Tonya Pierce
 * Lab Section: 20
 * Lab Instructor: Dr. Tonya Pierce 
 */
package edu.ilstu.jclomel;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 * <insert class description here>
 *
 * @author Justin Lomelino
 *
 */
public class CustomerOutput
{
	
	public static void writeToFile(String contents, String fileName){
		try
		{
			File file = new File(fileName);
			FileWriter fw = new FileWriter(file, true);
			fw.write(contents + "\n\n");
			fw.close();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}
}
