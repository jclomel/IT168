/*
 * File name: Data.java
 *
 * Programmer: Justin Lomelino
 * ULID: jclomel
 *
 * Date: Nov 12, 2016
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Dr. Tonya Pierce
 * Lab Section: 20
 * Lab Instructor: Dr. Tonya Pierce 
 */
package edu.ilstu.jclomel;

/**
 * <insert class description here>
 *
 * @author Justin Lomelino
 *
 */
public class Data
{
	private final double RATE = 0.027;
	private int megabits;
	
	Data(){
		this(-1);	//a negative number of megabits doesn't make sense, 
					//so this is a good way to indicate the variable was uninitialized.
	}
	Data(int megabits){
		this.megabits = megabits;
	}
	
	public double getRate(){
		return RATE;
	}
	public int getMegabits(){
		return megabits;
	}
	public void setMegabits(int megabits){
		this.megabits = megabits;
	}
	public double calculateBill(){
		return (megabits * RATE);
	}
}
