/*
 * File name: Address.java
 *
 * Programmer: Justin Lomelino
 * ULID: jclomel
 *
 * Date: Nov 12, 2016
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Dr. Tonya Pierce
 * Lab Section: 20
 * Lab Instructor: Dr. Tonya Pierce 
 */
package edu.ilstu.jclomel;

/**
 * <insert class description here>
 *
 * @author Justin Lomelino
 *
 */
public class Address
{
	private String street;
	private String city;
	private String state;
	private String zip;
	
	Address(){
		this("no street", "no city", "no state", "no zip");
	}
	
	Address(String street, String city, String state, String zip){
		this.street = street;
		this.city = city;
		this.state = state;
		this.zip = zip;
	}
	
	public String getStreet(){
		return street;
	}
	public String getCity(){
		return city;
	}
	public String getState(){
		return state;
	}
	public String getZip(){
		return zip;
	}
	public void setStreet(String street){
		this.street = street;
	}
	public void setCity(String city){
		this.city = city;
	}
	public void setState(String state){
		this.state = state;
	}
	public void setZip(String zip){
		this.zip = zip;
	}
}
