/*
 * File name: BillingApp.java
 *
 * Programmer: Justin Lomelino
 * ULID: jclomel
 *
 * Date: Nov 12, 2016
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Dr. Tonya Pierce
 * Lab Section: 20
 * Lab Instructor: Dr. Tonya Pierce 
 */
package edu.ilstu.jclomel;

import java.io.File;
import java.util.Scanner;

/**
 * <insert class description here>
 *
 * @author Justin Lomelino
 *
 */
public class BillingApp
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		Scanner kb = new Scanner(System.in);
		System.out.print("Please enter the filename or just press enter to use the default file('Wireless.csv'): ");
		String filename = kb.nextLine();
		if(filename.equals("\n") || filename.equals("")){
			filename = "Wireless.csv";
		}
		kb.close();
		
		File file = null;
		try{
			file = new File(filename);
			if(file.exists()){
				System.out.println("'" +filename + "' will be used.");
			}
			CustomerInput ci = new CustomerInput(file);
			System.out.println("Reading file...");
			ci.readFile();
			System.out.println("Contents of '" + filename + "' were successfullly written to '" + ci.getOutputFile() + "'.");
			System.out.println("Goodbye!");
			System.exit(0);
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
		

		
	}

}
