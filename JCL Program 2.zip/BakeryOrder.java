/*
 * File name: BakeryOrder.java
 *
 * Programmer: Justin Lomelino
 * ULID: jclomel
 *
 * Date: Sep 24, 2016
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Dr. Tonya Pierce
 * Lab Section: 20
 * Lab Instructor: Dr. Tonya Pierce 
 */
package edu.ilstu;

/**
 * Represents one 'order' in the bakery.  This class is responsible for spawning
 * the basket, and calling the methods that make the order progress.  Basically, the
 * main algorithm for the program resides here.
 *
 * @author Justin Lomelino
 *
 */
public class BakeryOrder
{
	private BakeryMenu menu;
	private BakeryBasket basket;

	public BakeryOrder(){
		// Since we haven't covered exceptions yet, I will print a message to the screen and
		// quit instead.  This constructor should never be called without arguments.
		System.out.println("BakeryOrders must have a BakeryMenu!");
		System.exit(1);
	}
	public BakeryOrder(BakeryMenu menu){
		this.menu = menu;
	}
	
	// This method is not used in this program; it is simply here to allow future use if necessary.	
	public BakeryMenu getMenu(){
		return menu;
	}
	// This method is not used in this program; it is simply here to allow future use if necessary.
	public BakeryBasket getBasket(){
		return basket;
	}
	
	public void processOrder(){
		// This method actually creates an order, by creating a BakeryBasket object
		// and running various methods from the object in order to get order numbers
		// from the user, calculate totals, and display the receipt.
		basket = new BakeryBasket(menu);
		menu.displayMenu();
		basket.getOrderAmountsInput();
		basket.calculateOrderTotals();
		basket.displayReciept();
	}
	
	
}
