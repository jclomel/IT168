/*
 * File name: BakeryDriver.java
 *
 * Programmer: Justin Lomelino
 * ULID: jclomel
 *
 * Date: Sep 24, 2016
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Dr. Tonya Pierce
 * Lab Section: 20
 * Lab Instructor: Dr. Tonya Pierce 
 */
package edu.ilstu;

/**
 * Bakery Driver contains the main function for a bakery shopping cart.
 * On run, the program displays a menu and then asks the user for
 * the number of items of each type on the menu.  Then, based on the user's
 * input, it displays an order receipt including tax and carry-out charge.
 *
 * @author Justin Lomelino
 *
 */
public class BakeryDriver
{

	public static void main(String[] args)
	{
		BakeryMenu menu = new BakeryMenu();
		BakeryOrder order = new BakeryOrder(menu);
		order.processOrder();

	}

}
