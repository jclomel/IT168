/*
 * File name: BakeryMenu.java
 *
 * Programmer: Justin Lomelino
 * ULID: jclomel
 *
 * Date: Sep 24, 2016
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Dr. Tonya Pierce
 * Lab Section: 20
 * Lab Instructor: Dr. Tonya Pierce 
 */
package edu.ilstu;

/**
 * Represents the bakery menu.  Contains the prices for each of the items sold in the
 * bakery, as well as the tax rate and carry out rate.  Also has a method for producing a
 * nice display of the menu
 *
 * @author Justin Lomelino
 *
 */
public class BakeryMenu
{
	// Because the prices and fees are unlikely to change during an order, they are set as constants
	// in this program when the menu is instantiated.  Since the values are constants, they
	// must be declared when the object is instantiated, and thus the constructor requires
	// these prices.  There are no setters for these prices because the values are final.  If
	// the prices need to be updated, it is simple to instantiate a new BakeryMenu with the 
	// corrected values by using the second constructor below.
	private final double COOKIE_PRICE;
	private final double DONUT_PRICE;
	private final double CAKE_PRICE;
	private final double PIE_PRICE;
	private final double TAX_RATE;
	private final double CARRY_OUT_CHARGE;
	
	public BakeryMenu(){
		// these default values come from the programming assignment specifications.  The program 
		// defaults to the prices in the specification, but can be easily changed to other 
		// prices by calling the other constructor and feeding it different prices.  Tax rate 
		// has been set to 7% instead of 7.5% (the value in the specification) per the 
		// instructor's directions in class.
		this(0.70, 1.25, 6.50, 8.50, 0.07, 0.10);
	}
	public BakeryMenu(double cookiePrice, double donutPrice, double cakePrice, double piePrice, double taxRate, double carryOutCharge){
		COOKIE_PRICE = cookiePrice;
		DONUT_PRICE = donutPrice;
		CAKE_PRICE = cakePrice;
		PIE_PRICE = piePrice;
		TAX_RATE = taxRate;
		CARRY_OUT_CHARGE = carryOutCharge;
	}
	
	public double getCookiePrice(){
		return COOKIE_PRICE;
	}
	public double getDonutPrice(){
		return DONUT_PRICE;
	}
	public double getCakePrice(){
		return CAKE_PRICE;
	}
	public double getPiePrice(){
		return PIE_PRICE;
	}
	public double getTaxRate(){
		return TAX_RATE;
	}
	public double getCarryOutCharge(){
		return CARRY_OUT_CHARGE;
	}
	
	public void displayMenu(){
		// prints a nice display of the BakeryMenu's prices
		System.out.println("    Bakery Shop Menu\n");
		System.out.printf("Cookie        $%.2f\n", COOKIE_PRICE);
		System.out.printf("Donut         $%.2f\n", DONUT_PRICE);
		System.out.printf("Cake          $%.2f\n", CAKE_PRICE);
		System.out.printf("Pie           $%.2f\n\n\n", PIE_PRICE);
	}
}
