/*
 * File name: BakeryBasket.java
 *
 * Programmer: Justin Lomelino
 * ULID: jclomel
 *
 * Date: Sep 24, 2016
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Dr. Tonya Pierce
 * Lab Section: 20
 * Lab Instructor: Dr. Tonya Pierce 
 */
package edu.ilstu;

import java.util.Scanner;

/**
 * Represents a 'basket'.  Holds all information about how many of each item is ordered, as 
 * well as methods to calculate the totals and display the order summary.
 *
 * @author Justin Lomelino
 *
 */
public class BakeryBasket
{
	private BakeryMenu menu;
	private int numCookies;
	private int numDonuts;
	private int numCakes;
	private int numPies;
	private double subTotal;
	private double taxTotal;
	private double carryoutTotal;
	private double total;
	
	public BakeryBasket(){
		// Since we haven't covered exceptions yet, I will print a message to the screen and
		// quit instead.  This constructor should never be called without arguments.
		System.out.println("BakeryBaskets must have a BakeryMenu!");
		System.exit(1);
	}
	public BakeryBasket(BakeryMenu menu){
		this.menu = menu;
	}

	public int getNumCookies(){
		return numCookies;
	}
	public int getNumDonuts(){
		return numDonuts;
	}
	public int getNumCakes(){
		return numCakes;
	}
	public int getNumPies(){
		return numPies;
	}
	
	public void setNumCookies(int cookies){
		numCookies = cookies;
	}
	public void setNumDonuts(int donuts){
		numDonuts = donuts;
	}
	public void setNumCakes(int cakes){
		numCakes = cakes;
	}
	public void setNumPies(int pies){
		numPies = pies;
	}
	
	public void getOrderAmountsInput(){
		Scanner keys = new Scanner(System.in);
		System.out.print("Enter the number of cookies: ");
		setNumCookies(keys.nextInt());
		System.out.print("Enter the number of donuts: ");
		setNumDonuts(keys.nextInt());
		System.out.print("Enter the number of cakes: ");
		setNumCakes(keys.nextInt());
		System.out.print("Enter the number of pies: ");
		setNumPies(keys.nextInt());
		System.out.println("\n");
		keys.close();
	}
	
	public void calculateOrderTotals(){
		subTotal = calculateSubTotal();
		taxTotal = calculateTaxTotal(subTotal);
		carryoutTotal = calculateCarryoutTotal(taxTotal);
		total = subTotal + taxTotal + carryoutTotal;	
	}
	
	public double calculateSubTotal(){
		double totalForCookies = numCookies * menu.getCookiePrice();
		double totalForDonuts = numDonuts * menu.getDonutPrice();
		double totalForCakes = numCakes * menu.getCakePrice();
		double totalForPies = numPies * menu.getPiePrice();
		double subTotal = totalForCookies + totalForDonuts + totalForCakes + totalForPies;
		return subTotal;
	}
	public double calculateTaxTotal(double subTotal){
		return subTotal * menu.getTaxRate();
	}
	public double calculateCarryoutTotal(double taxTotal){
		return (subTotal +taxTotal) * menu.getCarryOutCharge();
	}
	
	public void displayReciept(){
		System.out.println("    Bakery Shop Order Summary\n");
		
		System.out.println("                Bakery Items Ordered:");
		System.out.println("Cookies             " + numCookies);
		System.out.println("Donuts              " + numDonuts);
		System.out.println("Cakes               " + numCakes);
		System.out.println("Pies                " + numPies + "\n");
		
		System.out.printf("Sub-total:    $ %.2f\n", subTotal);
		System.out.printf("Tax:          $ %.2f\n", taxTotal);
		System.out.printf("Carry-out:    $ %.2f\n", carryoutTotal);
		System.out.printf("Total bill:   $ %.2f\n", total);
	}
}
