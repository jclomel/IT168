/*
 * File name: Person.java
 *
 * Programmer: Justin Lomelino
 * ULID: jclomel
 *
 * Date: Oct 6, 2016
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Dr. Tonya Pierce
 * Lab Section: 20
 * Lab Instructor: Dr. Tonya Pierce 
 */
package edu.ilstu;

/**
 * Describes a person's name, gender, and marital status, with methods to examine that data
 *
 * @author Justin Lomelino
 *
 */
public class Person
{
	private String title;
	private String name;
	private String gender;
	private String maritalStatus;
	
	/* Since we have to make a default, let's call the constructor we actually want to use
	   and fill it with data that makes it clear the record was not initialized.
	*/
	public Person(){
		this("none", "undetermined", "probably single");
	}
	
	public Person(String name, String gender, String maritalStatus){
		this.name = name;
		this.gender = gender;
		this.maritalStatus = maritalStatus;
	}
	
	public void determineTitle(){
		if(gender.equals("M"))
			title = "Mr.";
		else
			if (maritalStatus.equals("S"))
				title = "Miss";
			else
				title = "Mrs.";
	}
	
	public boolean isValidGender(){
		if(gender.equals("M") || gender.equalsIgnoreCase("F"))
			return true;
		else
			return false;
	}
	
	public boolean isValidMaritalStatus(){
		if( maritalStatus.equals("S") || maritalStatus.equalsIgnoreCase("M"))
			return true;
		else
			return false;
	}
	public void setName(String name){
		this.name = name;
	}
	
	public void setGender(String gender){
		this.gender = gender.toUpperCase();
	}
	
	public void setMaritalStatus(String maritalStatus){
		this.maritalStatus = maritalStatus.toUpperCase();
	}
	
	public String getTitle(){
		return title;
	}
	
	public String getName(){
		return name;
	}
	
	public String getGender(){
		return gender;
	}
	
	public String getMaritalStatus(){
		return maritalStatus;
	}
}
