/*
 * File name: NumberCategory.java
 *
 * Programmer: Justin Lomelino
 * ULID: jclomel
 *
 * Date: Oct 6, 2016
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Dr. Tonya Pierce
 * Lab Section: 20
 * Lab Instructor: Dr. Tonya Pierce 
 */
package edu.ilstu;

import java.util.Scanner;

/**
 * determines if a number is positive, negative, or zero
 *
 * @author Justin Lomelino
 *
 */
public class NumberCategory
{
	public static void main(String[] args)
	{
		double num;
		Scanner keys = new Scanner(System.in);
		
		System.out.println("Enter a number (decimal points are okay):");
		num = keys.nextDouble();
		if (num > 0)
			System.out.printf("%f is positive.", num);
		else if (num == 0)
			System.out.printf("%f is zero.", num);
		else
			System.out.printf("%f is negative.", num);

	}

}
