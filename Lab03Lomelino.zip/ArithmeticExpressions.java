/*
 * Filename:
 *
 * Programmer:
 * ULID: 
 *
 * Date:  
 *
 * Class:  
 * Lecture Section:
 * Lecture Instructor:
 * Lab Section:
 * Lab Instructor:  
 */

package edu.ilstu;

/**
 * Write and test arithmetic expressions
 *
 * @author 
 *
 */
public class ArithmeticExpressions {

	public static void main(String[] args) {
		// Constant declaration
		int FREEZING = 32;
		
		
		
		// Variable declarations and initializations
		double height = 9.0;
		double base1 = 5.0;
		double base2 = 10.0;
		int fahrenheit = 78;
		int expected = 89;
		int observed = 78;
		double area;
		double celsius;
		double percentDiff;
		
		
		
		// Problem 17
		area = height / 2 * (base1 + base2);
		System.out.println("area: " + area);
		// Problem 18
		celsius = 5/9.0 *(fahrenheit - FREEZING);
		System.out.println("celsius: " + celsius);
		// Problem 19
		double doubleExpected = (double)expected;
		percentDiff =((doubleExpected-observed) / doubleExpected * 100);
		System.out.println("percent difference: " + percentDiff);
		
		
		
	
		
		
	}

}
