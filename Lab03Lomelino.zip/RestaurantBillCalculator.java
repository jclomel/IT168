/*
 * File name: RestaurantBillCalculator.java
 *
 * Programmer: Justin Lomelino
 * ULID: jclomel
 *
 * Date: Sep 6, 2016
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Dr. Tonya Pierce
 * Lab Section: 20
 * Lab Instructor: Dr. Tonya Pierce 
 */
package edu.ilstu;

/**
 * calculates the tip and total on a restaurant bill
 *
 * @author Justin Lomelino
 *
 */
public class RestaurantBillCalculator
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		double tipPercent = 0.15;
		double taxRate = 0.075;
		double mealCost = 45.75;
		double tax = 0;
		double tipAmount = 0;
		double total = 0;
		
		tax = mealCost * taxRate;
		tipAmount = mealCost * tipPercent;
		total = mealCost + tax + tipAmount;
		
		System.out.println("Meal Cost: " + mealCost);
		System.out.println("Tax: " + tax);
		System.out.println("Tip: " + tipAmount);
		System.out.println("Total amount: " + total);

	}

}
