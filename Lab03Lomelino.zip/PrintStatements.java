/*
 * Filename:
 *
 * Programmer:
 * ULID: 
 *
 * Date:  
 *
 * Class:  
 * Lecture Section:
 * Lecture Instructor:
 * Lab Section:
 * Lab Instructor:  
 */

package edu.ilstu;

/**
 * Print statements for given phrases
 *
 * @author 
 *
 */
public class PrintStatements {

	public static void main(String[] args) {
		//No variables need to be declared
		
		//Problem 1 print statements
		System.out.println("Everything is\nan object.\n");
		
		
		
		//Problem 2 print statements
		System.out.println("A program is a bunch of objects\ntelling each other\nwhat to do\nby sending messages.\n");
		
		
		
		//Problem 3 print statements
		System.out.println("OO Properties:\nencapsulation\ninheritance\npolymorphism\n");
		
		
		
		//Problem 4 print statements
		System.out.println("An\nobject\nhas\nstate\nbehavior\nand\nidentity\n");
		
		
		
		

	}

}
