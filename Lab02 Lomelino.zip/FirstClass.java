/*
 * File name: FirstClass.java
 *
 * Programmer: Justin Lomelino
 * ULID: jclomel
 *
 * Date: Aug 30, 2016
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Dr. Tonya Pierce
 * Lab Section: 20
 * Lab Instructor: Dr. Tonya Pierce 
 */

/**
 * A first program rearranging statements.
 *
 * @author Justin Lomelino
 *
 */
public class FirstClass
	{
	public static void main(String[] args)
		{
		System.out.println("Welcome to Java programming!");
		System.out.println("Java Rules!");
		System.out.print("My name is Justin Lomelino.\n");
		System.out.print("Success!\n");
		System.out.print("\nGoodbye!");
		}
	}


