/*
 * File name: DistanceCalculator.java
 *
 * Programmer: Justin Lomelino
 * ULID: jclomel
 *
 * Date: Aug 30, 2016
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Dr. Tonya Pierce
 * Lab Section: 20
 * Lab Instructor: Dr. Tonya Pierce 
 */

/**
 * calculates the distance of two given values
 *
 * @author Justin Lomelino
 *
 */
public class DistanceCalculator
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		int speed = 20;
		int time = 10;
		int distance = speed * time;
		System.out.println(distance);

	}

}
