/*
 * File name: Die.java
 *
 * Programmer: Justin Lomelino
 * ULID: jclomel
 *
 * Date: Nov 1, 2016
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Dr. Tonya Pierce
 * Lab Section: 20
 * Lab Instructor: Dr. Tonya Pierce 
 */
package edu.ilstu;

import java.util.Random;

/**
 * represents a 6 sided die
 *
 * @author Justin Lomelino
 *
 */
public class Die
{
	private int spots;
	private Random generator;
	
	Die(){
		this.generator = new Random();
	}
	public void roll(){
		spots = (generator.nextInt(6) + 1);
	}
	public int getSpots(){
		return spots;
	}
	public boolean equals(Die other){
		if(spots == other.spots){
			return true;
		}
		else{
			return false;
		}
	}
}
