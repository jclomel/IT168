/*
 * File name: DiceSimulatorDriver.java
 *
 * Programmer: Justin Lomelino
 * ULID: jclomel
 *
 * Date: Nov 1, 2016
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Dr. Tonya Pierce
 * Lab Section: 20
 * Lab Instructor: Dr. Tonya Pierce 
 */
package edu.ilstu;

/**
 * main method for testing the dice simulation
 *
 * @author Justin Lomelino
 *
 */
public class DiceSimulatorDriver
{
	public static void main(String[] args)
	{
		DiceSimulator ds = new DiceSimulator();
		DiceAccumulator results;
		int numRolls = 10000;
		results = ds.runSimulation(numRolls);
		DiceOutput.printReport(results);

	}

}
