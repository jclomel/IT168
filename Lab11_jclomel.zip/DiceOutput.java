/*
 * File name: DiceOutput.java
 *
 * Programmer: Justin Lomelino
 * ULID: jclomel
 *
 * Date: Nov 1, 2016
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Dr. Tonya Pierce
 * Lab Section: 20
 * Lab Instructor: Dr. Tonya Pierce 
 */
package edu.ilstu;

/**
 * <insert class description here>
 *
 * @author Justin Lomelino
 *
 */
public class DiceOutput
{
	public static void printReport(DiceAccumulator da){
		System.out.printf("Number of rolls:\t%5d%n", 10000);
		System.out.printf("Number of snake eyes:\t%5d%n", da.getSnakeEyes());
		System.out.printf("Number of twos:\t\t%5d%n", da.getTwos());
		System.out.printf("Number of threes:\t%5d%n", da.getThrees());
		System.out.printf("Number of fours:\t%5d%n", da.getFours());
		System.out.printf("Number of fives:\t%5d%n", da.getFives());
		System.out.printf("Number of sixes:\t%5d%n", da.getSixes());
	}
}
