/*
 * File name: DiceAccumulator.java
 *
 * Programmer: Justin Lomelino
 * ULID: jclomel
 *
 * Date: Nov 1, 2016
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Dr. Tonya Pierce
 * Lab Section: 20
 * Lab Instructor: Dr. Tonya Pierce 
 */
package edu.ilstu;

/**
 * contains counters for the count of how many times both dice rolled the
 * same number for each number rolled
 *
 * @author Justin Lomelino
 *
 */
public class DiceAccumulator
{
	private int snakeEyes;
	private int twos;
	private int threes;
	private int fours;
	private int fives;
	private int sixes;
	
	public void addSnakeEyes(){
		snakeEyes +=1;
	}
	public void addTwos(){
		twos +=1;
	}
	public void addThrees(){
		threes +=1;
	}
	public void addFours(){
		fours +=1;
	}
	public void addFives(){
		fives +=1;
	}
	public void addSixes(){
		sixes +=1;
	}
	public int getSnakeEyes(){
		return snakeEyes;
	}
	public int getTwos(){
		return twos;
	}
	public int getThrees(){
		return threes;
	}
	public int getFours(){
		return fours;
	}
	public int getFives(){
		return fives;
	}
	public int getSixes(){
		return sixes;
	}
}
