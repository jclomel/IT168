/*
 * File name: DiceSimulator.java
 *
 * Programmer: Justin Lomelino
 * ULID: jclomel
 *
 * Date: Nov 1, 2016
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Dr. Tonya Pierce
 * Lab Section: 20
 * Lab Instructor: Dr. Tonya Pierce 
 */
package edu.ilstu;

/**
 * controls the running of the dice simulation
 *
 * @author Justin Lomelino
 *
 */
public class DiceSimulator
{
	public DiceAccumulator runSimulation(int numRolls){
		DiceAccumulator da = new DiceAccumulator();
		Die die1 = new Die();
		Die die2 = new Die();
		
		for(int i=0; i<=numRolls; i++){
			die1.roll();
			die2.roll();
			
			if(die1.equals(die2)){
				switch(die1.getSpots()){
				case 1:
					da.addSnakeEyes();
					break;
				case 2:
					da.addTwos();
					break;
				case 3:
					da.addThrees();
					break;
				case 4:
					da.addFours();
					break;
				case 5:
					da.addFives();
					break;
				default:
					da.addSixes();
					break;
				}
			}
		}
		return da;
	}
}
