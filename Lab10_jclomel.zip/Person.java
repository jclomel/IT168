/*
 * File name: Person.java
 *
 * Programmer: Justin Lomelino
 * ULID: jclomel
 *
 * Date: Oct 27, 2016
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Dr. Tonya Pierce
 * Lab Section: 20
 * Lab Instructor: Dr. Tonya Pierce 
 */
package edu.ilstu;

/**
 * represents a person, containing their name and age
 *
 * @author Justin Lomelino
 *
 */
public class Person
{
	private String firstName;
	private String lastName;
	private int age;
	
	Person(String firstName, String lastName, int age){
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
	}
	Person(){
		this("Anon", "Ymous", 999);
	}
	
	public String getFirstName(){
		return firstName;
	}
	public String getLastName(){
		return lastName;
	}
	public int getAge(){
		return age;
	}
	public void setFirstName(String firstName){
		this.firstName = firstName;
	}
	public void setLastName(String lastName){
		this.lastName = lastName;
	}
	public void setAge(int age){
		this.age = age;
	}
	public String toString(){
		return firstName + " " + lastName + ", " + age + " years old";
	}
	public boolean equals(Person otherPerson){
		boolean returnValue;
		if((firstName == otherPerson.getFirstName()) && (lastName == otherPerson.getLastName())){
			returnValue = true;
		}
		else{
			returnValue = false;
		}
		return returnValue;
	}
}
