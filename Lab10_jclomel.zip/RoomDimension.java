/*
 * File name: RoomDimension.java
 *
 * Programmer: Justin Lomelino
 * ULID: jclomel
 *
 * Date: Oct 27, 2016
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Dr. Tonya Pierce
 * Lab Section: 20
 * Lab Instructor: Dr. Tonya Pierce 
 */
package edu.ilstu;

/**
 * represents the dimensions of a room
 *
 * @author Justin Lomelino
 *
 */
public class RoomDimension
{
	double length;
	double width;
	
	RoomDimension(double length, double width){
		this.length = length;
		this.width = width;
	}

	public double calculateArea()
	{
		return length * width;
	}
	
	public String toString(){
		return "Length: " + length +"\nWidth: " + width + "\n";
	}

}
