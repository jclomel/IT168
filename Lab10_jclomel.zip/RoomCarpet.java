/*
 * File name: RoomCarpet.java
 *
 * Programmer: Justin Lomelino
 * ULID: jclomel
 *
 * Date: Oct 27, 2016
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Dr. Tonya Pierce
 * Lab Section: 20
 * Lab Instructor: Dr. Tonya Pierce 
 */
package edu.ilstu;

/**
 * represents the carpet job
 *
 * @author Justin Lomelino
 *
 */

public class RoomCarpet
{
	RoomDimension dimensions;
	double carpetPricePerSquareFoot;
	
	RoomCarpet(RoomDimension dimensions, double ppsf){
		//ppsf = price per square foot
		this.dimensions = dimensions;
		this.carpetPricePerSquareFoot = ppsf;
	}
	
	public double calculateTotalCost(){
		return (dimensions.calculateArea()) * carpetPricePerSquareFoot;
	}
	public String toString(){
		return dimensions.toString() + "Carpet Cost: " + carpetPricePerSquareFoot +"\n";
	}
	
}
