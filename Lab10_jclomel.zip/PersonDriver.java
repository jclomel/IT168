/*
 * File name: PersonDriver.java
 *
 * Programmer: Justin Lomelino
 * ULID: jclomel
 *
 * Date: Oct 27, 2016
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Dr. Tonya Pierce
 * Lab Section: 20
 * Lab Instructor: Dr. Tonya Pierce 
 */
package edu.ilstu;

/**
 * <insert class description here>
 *
 * @author Justin Lomelino
 *
 */
public class PersonDriver
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		Person p1 = new Person("Abe", "Lincoln", 207);
		//Person p2 = new Person("Abe", "Lincoln", 207);
		//Person p2 = new Person("Donald", "Trump", 70);
		Person p2 = new Person("Abe", "Lincoln", 300);
		
		if(p1.equals(p2)){
			System.out.println(p1.toString() + " and");
			System.out.println(p2.toString());
			System.out.println("have the same name\n");
		}
		else{
			System.out.println(p1.toString() + " and");
			System.out.println(p2.toString());
			System.out.println("have different names\n");
		}
		
		if(p1.getAge() == p2.getAge()){
			System.out.println(p1.toString() + " and");
			System.out.println(p2.toString());
			System.out.println("are the same age");
		}
		else if(p1.getAge() > p2.getAge()){
			System.out.println(p1.toString() + " is older");
			System.out.println(p2.toString());
		}
		else{
			System.out.println(p1.toString() + " is younger");
			System.out.println(p2.toString());
		}

	}

}
