package edu.ilstu;

public class LoanApplication
{
	String name;
	String city;
	double annualIncome;
	int creditScore;
	
	LoanApplication(String name, String city, double annualIncome, int creditScore){
		this.name = name;
		this.city = city;
		this.annualIncome = annualIncome;
		this.creditScore = creditScore;
	}
	LoanApplication(){
		this("anon", "Nowhere", 0, 0);
	}
	
	public int calculateLoan(){
		int rv = 0;
		if(isApproved()){
			if((creditScore > 600) && (creditScore < 700)){
				rv = (int)(annualIncome * 2.8);
			}
			else if((creditScore > 700) && (creditScore < 800)){
				rv = (int)(annualIncome*5.5);
			}
			else if(creditScore >= 800){
				rv = (int)(annualIncome*6.1);
			}
		}
		else{
			rv = 0;
		}
		return rv;
	}
	public String getName(){
		return name;
	}
	private boolean isApproved(){
		boolean rv;
		if(creditScore < 600){
			rv = false;
		}
		else{
			rv = true;
		}
		return rv;
	}
		
}
