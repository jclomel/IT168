/*
 * Justin Lomelino
 * Section: Pierce, Tuesday night lab
 */

package edu.ilstu;

public class LoanApplicationTester
{
	 
	public static void main(String[] args)
	{
		LoanApplication application = new LoanApplication("Peter Griffin","Quahog", 32890.91, 590);
		int loan = application.calculateLoan();
		if (loan == 0)
			System.out.println("Sorry, "+application.getName()+"." +" Your application has been denied.");
		else
			System.out.println("Congratulations! "+application.getName()+"."+ 
								" Your application has been approved. And the approved loan is "+
								loan+" .");
		
		application = new LoanApplication("Glen Quagmire", "Quahog", 45000.06, 650);
		loan = application.calculateLoan();
		if (loan == 0)
			System.out.println("Sorry, "+application.getName()+"." +" Your application has been denied.");
		else
			System.out.println("Congratulations! "+application.getName()+"."+ 
								" Your application has been approved. And the approved loan is "+
								loan+" .");
								
		application = new LoanApplication("Joe Swanson", "Quahog", 37000, 750);
		loan = application.calculateLoan();
		if (loan == 0)
			System.out.println("Sorry, "+application.getName()+"." +" Your application has been denied.");
		else
			System.out.println("Congratulations! "+application.getName()+"."+ 
								" Your application has been approved. And the approved loan is "+
								loan+" .");		

		application = new LoanApplication("Elmer Hartman", "Quahog", 54000, 810);
		loan = application.calculateLoan();
		if (loan == 0)
			System.out.println("Sorry, "+application.getName()+"." +" Your application has been denied.");
		else
			System.out.println("Congratulations! "+application.getName()+"."+ 
								" Your application has been approved. And the approved loan is "+
								loan+" .");	
	}
}