/*
 * File name: AverageWaterUseDriver.java
 *
 * Programmer: Justin Lomelino
 * ULID: jclomel
 *
 * Date: Oct 6, 2016
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Dr. Tonya Pierce
 * Lab Section: 20
 * Lab Instructor: Dr. Tonya Pierce 
 */
package edu.ilstu;

/**
 * tests the averageWaterUseCalculator class
 *
 * @author Justin Lomelino
 *
 */
public class AverageWaterUseDriver
{


	public static void main(String[] args)
	{
		int useAugust = 723;
		int useSeptember = 801;
		int useOctober = 720;
		double average;
		AverageWaterUseCalculator calc = new AverageWaterUseCalculator();
		average = calc.calculateWaterUseAverage(useAugust, useSeptember, useOctober);
		System.out.printf("Average: %.2f", average);

	}

}
