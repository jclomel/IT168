/*
 * File name: StringExperiment.java
 *
 * Programmer: Justin Lomelino
 * ULID: jclomel
 *
 * Date: Sep 18, 2016
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Dr. Tonya Pierce
 * Lab Section: 20
 * Lab Instructor: Dr. Tonya Pierce 
 */
package edu.ilstu;

/**
 * Displays the given name in different ways.
 *
 * @author Justin Lomelino
 *
 */
public class StringExperiment
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		String firstName = "Justin";
		String middleName = "Clark";
		String lastName = "Lomelino";
		
		System.out.println(firstName + " " + middleName + " " + lastName);
		System.out.println(firstName + " " + middleName.charAt(0) + ". " + lastName);
		System.out.println(firstName.toUpperCase() + " " + lastName.toLowerCase());
		System.out.println("Length of last name = " + lastName.length());
		int lastNameMiddlePos = lastName.length()/2;
		System.out.println(lastName.charAt(lastNameMiddlePos));
		System.out.println(firstName.charAt(firstName.length()-1));

	}

}
